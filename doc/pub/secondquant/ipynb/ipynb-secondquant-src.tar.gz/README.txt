This IPython notebook secondquant.ipynb does not require any additional
programs.
